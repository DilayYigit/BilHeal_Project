{{--
    @extends('layouts.app')

    @section('content')
        document.show template
    @endsection
--}}
