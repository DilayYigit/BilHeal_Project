{{--
    @extends('layouts.app')

    @section('content')
        report.show template
    @endsection
--}}
