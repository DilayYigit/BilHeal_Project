{{--
    @extends('layouts.app')

    @section('content')
        diagnosis.show template
    @endsection
--}}
