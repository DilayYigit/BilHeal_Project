{{--
    @extends('layouts.app')

    @section('content')
        vaccine.show template
    @endsection
--}}
