{{--
    @extends('layouts.app')

    @section('content')
        blood-donation-request.create template
    @endsection
--}}
