{{--
    @extends('layouts.app')

    @section('content')
        blood-donation-request.index template
    @endsection
--}}
