{{--
    @extends('layouts.app')

    @section('content')
        appointment.create template
    @endsection
--}}
