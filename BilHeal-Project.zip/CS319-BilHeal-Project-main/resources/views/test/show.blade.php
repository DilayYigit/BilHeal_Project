{{--
    @extends('layouts.app')

    @section('content')
        test.show template
    @endsection
--}}
