{{--
    @extends('layouts.app')

    @section('content')
        transaction.index template
    @endsection
--}}
