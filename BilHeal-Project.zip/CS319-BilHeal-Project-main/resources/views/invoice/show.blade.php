{{--
    @extends('layouts.app')

    @section('content')
        invoice.show template
    @endsection
--}}
