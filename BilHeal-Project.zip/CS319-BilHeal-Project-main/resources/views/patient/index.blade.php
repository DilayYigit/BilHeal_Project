{{--
    @extends('layouts.app')

    @section('content')
        patient.index template
    @endsection
--}}
