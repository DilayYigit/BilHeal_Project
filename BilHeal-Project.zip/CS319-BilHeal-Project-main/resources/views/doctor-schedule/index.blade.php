{{--
    @extends('layouts.app')

    @section('content')
        doctor-schedule.index template
    @endsection
--}}
