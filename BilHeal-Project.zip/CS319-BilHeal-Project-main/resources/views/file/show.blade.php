{{--
    @extends('layouts.app')

    @section('content')
        file.show template
    @endsection
--}}
